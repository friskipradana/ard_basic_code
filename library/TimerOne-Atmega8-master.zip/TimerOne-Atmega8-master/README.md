# TimerOne-Atmega8
TimerOne using 16bit Timer

This is modified from

http://www.pjrc.com/teensy/td_libs_TimerOne.html

https://github.com/PaulStoffregen/TimerOne

